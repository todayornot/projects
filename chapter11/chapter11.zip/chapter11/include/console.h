#ifndef _ORANGES_CONSOLE_H_
#define _ORANGES_CONSOLE_H_

typedef struct s_console
{
	unsigned	int	crtc_start;		/* set CRTC start addr reg */
	unsigned	int	orig;			/* start addr of the console */
	unsigned	int	con_size;			/* 当前控制台占的显存大小 */
	unsigned	int	cursor;				/* 当前光标位置 */
	int			is_full;
}CONSOLE;

#define SCR_UP	1	/* scroll forward */
#define SCR_DN	-1	/* scroll backward */

#define SCR_SIZE			(80 * 25)
#define SCR_WIDTH		80

#define DEFAULT_CHAR_COLOR	(MAKE_COLOR(BLACK, WHITE))
#define GRAY_CHAR			(MAKE_COLOR(BLACK, BLACK) | BRIGHT)
#define RED_CHAR				(MAKE_COLOR(BLUE, RED) | BRIGHT)


#endif /* _ORANGES_CONSOLE_H_ */